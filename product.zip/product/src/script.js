// coded by @atjonathan
// eslint-disable-next-line no-unused-vars
const projectName = 'product-landing-page';
