// coded by @ChaituVR
// eslint-disable-next-line no-unused-vars
const projectName = 'technical-docs-page';
