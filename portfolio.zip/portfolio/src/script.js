// coded by @lasjorg
// eslint-disable-next-line no-unused-vars
const projectName = 'portfolio';
