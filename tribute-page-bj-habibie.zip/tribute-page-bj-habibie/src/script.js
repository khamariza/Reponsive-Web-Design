// eslint-disable-next-line no-unused-vars
const projectName = 'tribute-page';

